<?php
session_start();
 include 'Dbconnection.php'; 
if ($_SERVER['REQUEST_METHOD']=="POST")
{
    $sql="SELECT * FROM `user` WHERE `email`='$_REQUEST[email]' AND `password`='$_REQUEST[password]'";
    $result = mysqli_query(mysql: $conn, query: $sql);
    $row = mysqli_fetch_assoc($result);

    if (mysqli_num_rows($result) > 0) 
    {
         if ($row['status']=='deactive' ) 
            {          
                $_SESSION["error_message"] = "This User is Not Activated";
                //echo "deactive part";
                //exit;
                header('Location: index.php');      
            }
            else 
            {
                $_SESSION["user_name"] = $row['firstname'];
                //echo "dashboard part";
               // exit;
                header('Location: dashboard.php');     
            }
    }
    else
    {
                $_SESSION['error_message'] = "No record found for this User!...";
                //echo "usernot found part";
                //exit;
                header('Location: index.php');
    }


} 




   /*  if($_SERVER['REQUEST_METHOD']=="POST") 
            {
                $sql="SELECT * FROM `user` WHERE `email`='$_REQUEST[email]' and `password`='$_REQUEST[password]'";
                 //$sql="INSERT INTO `user`(`firstname`, `lastname`, `email`, `password`, `status`) VALUES ('$_REQUEST[firstname]','$_REQUEST[lastname]','$_REQUEST[email]','$_REQUEST[password]','deactive')";        
             //echo $sql; exit;
                 $result = mysqli_query(mysql: $conn, query: $sql);
                 $row = mysqli_fetch_assoc($result);
                    //echo $row['status'];
                    //  exit;
                     if (mysqli_num_rows($result) > 0) {
                   
                  // echo $row['status'];
                    //exit;
                    //echo $row['status'];
                   // exit;
                    if ($row['status']!='deactive' ) {
                        
                        // header(header: 'Location: index.php');
                        // $_SESSION['success_message'] = "welcome user ";
                        $_SESSION["user_name"] = $row['firstname'];
                         header('Location: dashboard.php');
                        
                    }
                    else
                        {
                           
                            $_SESSION["user_name"] = "This User Not Activated";
                             header('Location: index.php');
                        }
                     } 
                       if (mysqli_num_rows($result) < 0) {
                       $_SESSION['error_message'] = "No record found for the given ID";
                           header('Location: index.php');
                
                       }
                    
                    //echo "No record found for the given ID.";
                

               // $user =  $result['firs
             }*/
       
       

?>
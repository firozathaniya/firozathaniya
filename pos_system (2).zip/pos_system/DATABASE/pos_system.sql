-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 02, 2025 at 03:28 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `pos_system`
--

-- --------------------------------------------------------

--
-- Table structure for table `party`
--

CREATE TABLE `party` (
  `party_id` int(11) NOT NULL,
  `partyname` varchar(100) NOT NULL,
  `partycity` varchar(100) NOT NULL,
  `partygroup` varchar(100) NOT NULL,
  `partycontact` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `party`
--

INSERT INTO `party` (`party_id`, `partyname`, `partycity`, `partygroup`, `partycontact`) VALUES
(1, 'Barkati Motot Com', 'Kanodar', 'Sales', 2147483647),
(2, 'Azad Auto Accessories', 'Kanodar', 'Purchase', 2147483647),
(3, 'Raj Motors', 'Kanodar', 'Loan', 2147483647),
(4, 'Barkati Motot Com', 'Chhapi', 'Purchase', 2147483647),
(5, '', '', '', 0),
(6, '', '', '', 0),
(7, '', '', '', 0),
(8, '', '', '', 0),
(9, '', '', '', 0),
(10, '', 'Kanodar', '3', 2147483647),
(11, '', 'Kanodar', '1', 2147483647);

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `productid` int(11) NOT NULL,
  `productname` varchar(200) NOT NULL,
  `unit` varchar(50) NOT NULL,
  `prate` int(11) NOT NULL,
  `srate` int(11) NOT NULL,
  `stock` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`productid`, `productname`, `unit`, `prate`, `srate`, `stock`) VALUES
(1, 'Tata ace PC--', 'kgs', 1500, 1700, 15),
(2, 'TATA ACE SS', 'pcs', 2000, 2300, 10),
(3, 'GOOVE', 'kgs', 100, 200, 10),
(4, 'Bolero T3 Gold', 'pcs', 1800, 2000, 15),
(5, 'sumo victa thunder', 'pcs', 1500, 2000, 10);

-- --------------------------------------------------------

--
-- Table structure for table `sales`
--

CREATE TABLE `sales` (
  `salesid` int(11) NOT NULL,
  `party_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `qty` int(11) NOT NULL,
  `rate` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `sales_tmp`
--

CREATE TABLE `sales_tmp` (
  `sales_temp_id` int(11) NOT NULL,
  `item_id` int(11) NOT NULL,
  `qty` int(11) NOT NULL,
  `rate` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `firstname` varchar(50) NOT NULL,
  `lastname` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(100) NOT NULL,
  `status` enum('activa','deactive') NOT NULL DEFAULT 'deactive',
  `role` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `firstname`, `lastname`, `email`, `password`, `status`, `role`) VALUES
(1, 'firozbhai', 'athaniya', 'firojathaniya57@gmail.com', '12345', 'activa', 'superadmin'),
(2, 'mohsinkhan', 'tamrani0', 'mohsin@gmail.com', '123456', 'deactive', ''),
(3, 'azad', 'auto', 'azadauto@gmail.com', '12345', 'activa', ''),
(4, 'mujahid', 'athaniya', 'mujahid@gmail.com', '12345', 'deactive', ''),
(5, 'bilal', 'sameja', 'bilalsameja@gmail.com', '12345', 'deactive', ''),
(6, 'bilal', 'sameja', 'firojathaniya57@gmail.com', '123456', 'deactive', ''),
(7, 'bilal', 'sameja', 'firojathaniya57@gmail.com', '1222', 'deactive', ''),
(8, 'bilal', 'sameja', 'firojathaniya57@gmail.com', '12345', 'deactive', ''),
(9, 'bilal', 'sameja', 'firojathaniya57@gmail.com', '12345', 'deactive', ''),
(10, 'bilal', 'sameja', 'firojathaniya57@gmail.com', '111111', 'deactive', ''),
(11, 'bilal', 'sameja', 'firojathaniya57@gmail.com', '11111', 'deactive', ''),
(12, 'bilal', 'sameja', 'firojathaniya57@gmail.com', '123456', 'deactive', ''),
(13, 'bilal', 'sameja', 'mohsin@gmail.com', '1111', 'deactive', ''),
(14, 'bilal', 'sameja', 'firojathaniya57@gmail.com', '12347777', 'deactive', ''),
(15, 'bilal', 'sameja', 'mohsin@gmail.com', '11111', 'deactive', ''),
(16, 'bilal', 'sameja', 'firojathaniya57@gmail.com', '123455555555', 'deactive', ''),
(17, 'bilal', 'sameja', 'firojathaniya57@gmail.com', '123456', 'deactive', ''),
(18, 'bilal', 'sameja', 'firojathaniya57@gmail.com', '111111', 'deactive', '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `party`
--
ALTER TABLE `party`
  ADD PRIMARY KEY (`party_id`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`productid`);

--
-- Indexes for table `sales`
--
ALTER TABLE `sales`
  ADD PRIMARY KEY (`salesid`);

--
-- Indexes for table `sales_tmp`
--
ALTER TABLE `sales_tmp`
  ADD PRIMARY KEY (`sales_temp_id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `party`
--
ALTER TABLE `party`
  MODIFY `party_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `product`
--
ALTER TABLE `product`
  MODIFY `productid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `sales`
--
ALTER TABLE `sales`
  MODIFY `salesid` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `sales_tmp`
--
ALTER TABLE `sales_tmp`
  MODIFY `sales_temp_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

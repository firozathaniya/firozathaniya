<?php include 'header.php'; ?>
<body id="page-top">

    <!-- Page Wrapper -->
    <div id="wrapper">

<?php include 'sidebar.php'; ?>
        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">
            <!-- Main Content -->
            <div id="content">
                <!-- Topbar -->
                <nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">
                    <!-- Sidebar Toggle (Topbar) -->
                    <button id="sidebarToggleTop" class="btn btn-link d-md-none rounded-circle mr-3">
                    <i class="fa fa-bars"></i>
                   </button>
                    <ul class="navbar-nav ml-auto">
                        <div class="topbar-divider d-none d-sm-block"></div>
                        <!-- Nav Item - User Information -->
                        <li class="nav-item dropdown no-arrow">
                            <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button"
                                data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                  <?php  if (isset($_SESSION['user_name'])) { ?>
                                <span class="mr-2 d-none d-lg-inline text-gray-600 small"><?php echo $_SESSION['user_name']; ?></span>
                                <?php } ?>
                               
                                <img class="img-profile rounded-circle"
                                    src="assets/img/undraw_profile.svg">
                            </a>
                            <!-- Dropdown - User Information -->
                            <div class="dropdown-menu dropdown-menu-right shadow animated--grow-in"
                                aria-labelledby="userDropdown">
                                <a class="dropdown-item" href="#">
                                    <i class="fas fa-user fa-sm fa-fw mr-2 text-gray-400"></i>
                                    Profile
                                </a>
                                <a class="dropdown-item" href="#">
                                    <i class="fas fa-cogs fa-sm fa-fw mr-2 text-gray-400"></i>
                                    Settings
                                </a>
                                <a class="dropdown-item" href="#">
                                    <i class="fas fa-list fa-sm fa-fw mr-2 text-gray-400"></i>
                                    Activity Log
                                </a>
                                <div class="dropdown-divider"></div>
                                <a class="dropdown-item" href="#" data-toggle="modal" data-target="#logoutModal">
                                    <i class="fas fa-sign-out-alt fa-sm fa-fw mr-2 text-gray-400"></i>
                                    Logout
                                </a>
                            </div>
                        </li>

                    </ul>

                </nav>
                <!-- End of Topbar -->

                <!-- Begin Page Content -->
                <div class="container-fluid">

                    <!-- Page Heading -->
                    <h1 class="h3 mb-4 text-gray-800">View Product   </h1>
    <div class="card shadow mb-4">
                        <div class="card-header py-3">
                             <a href="showproduct.php" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm"><i
                                class="fas fa-user fa-sm text-white-50"></i> Show Product</a>
                           

                            <?php
                                            if (isset($_SESSION['msg'])) {
                                                echo '<div class="alert alert-primary" role="alert">';
                                                echo $_SESSION['msg'];
                                                //echo $_SESSION['user'];
                                                
                                                echo '</div>';
                                                unset($_SESSION['msg']); // Clear the message after displaying
                                            }
                                            if (isset($_SESSION['msgerr'])) {

                                                 echo '<div class="alert alert-danger" role="alert">';
                                                echo $_SESSION['msgerr'];
                                                echo '</div>';
                                                 unset($_SESSION['msgerr']); // Clear the message after displaying

                                            }
                                     ?>
                        </div>
                        <div class="card-body">
<section class="vh-10 gradient-custom">
  <div class="container py-5 h-100">
    <div class="row justify-content-center align-items-center h-100">
      <div class="col-12 col-lg-9 col-xl-7">
        <div class="card shadow-2-strong card-registration" style="border-radius: 15px;">
          <div class="card-body p-4 p-md-5">
            <h3 class="mb-4 pb-2 pb-md-0 mb-md-5">Add Product</h3>
            <form method="post">
              <div class="row">
                <div class="col-md-6 mb-4">
                  <div data-mdb-input-init class="form-outline">
                    <label class="form-label" for="firstName">Product Name</label>
                    <input type="text" id="productname" name="productname" class="form-control form-control-lg" autofocus="ON" required />
                  </div>
                </div>
                <div class="col-md-6 mb-4">
<label class="form-label select-label" >Choose option</label>
                  <select class="select form-control-lg" name="unit" id="unit">
                    <option value="1" disabled>Choose Unit</option>
                    <option value="kgs">KGS</option>
                    <option value="pcs">PCS</option> 
                  </select>
                </div>
              </div>
              <div class="row">
                <div class="col-md-6 mb-4 d-flex align-items-center">
                     <div data-mdb-input-init class="form-outline datepicker w-100">
                        <label for="birthdayDate" class="form-label">Purchase Rate</label>
                    <input type="text" class="form-control form-control-lg" id="prate" name="prate" />  
                  </div>
                </div>
                <div class="col-md-6 mb-4">
                      <label for="birthdayDate" class="form-label">Sale Rate</label>
                     <div data-mdb-input-init class="form-outline datepicker w-100">
                    <input type="text" class="form-control form-control-lg" id="srate" name="srate" />
                  </div>
                </div>
              </div>

                 <div class="row">
                <div class="col-md-6 mb-4 d-flex align-items-center">
                     <div data-mdb-input-init class="form-outline datepicker w-100">
                        <label for="birthdayDate" class="form-label">Stock Value</label>
                    <input type="text" class="form-control form-control-lg" id="stock" name="stock" />  
                  </div>
                </div>
                
              </div>

              <div class="mt-4 pt-2">
                <input data-mdb-ripple-init class="btn btn-primary btn-lg" type="submit" value="Submit" name="submit" />
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>
                        </div>
                    </div>         
                <!-- /.container-fluid -->
            </div>
            <!-- End of Main Content -->
<?php include 'footer.php';  
        if (isset($_REQUEST['submit'])) {
            $sql="INSERT INTO `product`(`productname`, `unit`, `prate`, `srate`, `stock`) VALUES ('$_REQUEST[productname]','$_REQUEST[unit]','$_REQUEST[prate]','$_REQUEST[srate]','$_REQUEST[stock]')";
          // echo $sql; exit;
            $result = mysqli_query(mysql: $conn, query: $sql);
          //  $result=mysqli_query(mysql: $sql);
          if($result)
          {
            $_SESSION['msg']="Yor Product has been created successfully";
            header('Location:showproduct.php');
          }
          
        }
        
        
        
        ?>
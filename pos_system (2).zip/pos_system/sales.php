<?php include 'header.php'; ?>

<body id="page-top">

    <!-- Page Wrapper -->
    <div id="wrapper">

        <?php include 'sidebar.php'; ?>

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">
            <!-- Main Content -->
            <div id="content">
                <!-- Topbar -->
                <nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">
                    <!-- Sidebar Toggle (Topbar) -->
                    <button id="sidebarToggleTop" class="btn btn-link d-md-none rounded-circle mr-3">
                        <i class="fa fa-bars"></i>
                    </button>

                    <!-- Topbar Search -->


                    <!-- Topbar Navbar -->
                    <ul class="navbar-nav ml-auto">

                        <!-- Nav Item - Search Dropdown (Visible Only XS) -->
                        <li class="nav-item dropdown no-arrow d-sm-none">
                            <a class="nav-link dropdown-toggle" href="#" id="searchDropdown" role="button"
                                data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <i class="fas fa-search fa-fw"></i>
                            </a>
                            <!-- Dropdown - Messages -->
                            <div class="dropdown-menu dropdown-menu-right p-3 shadow animated--grow-in"
                                aria-labelledby="searchDropdown">
                                <form class="form-inline mr-auto w-100 navbar-search">
                                    <div class="input-group">
                                        <input type="text" class="form-control bg-light border-0 small"
                                            placeholder="Search for..." aria-label="Search"
                                            aria-describedby="basic-addon2">
                                        <div class="input-group-append">
                                            <button class="btn btn-primary" type="button">
                                                <i class="fas fa-search fa-sm"></i>
                                            </button>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </li>

                        <!-- Nav Item - Alerts -->
                        <li class="nav-item dropdown no-arrow mx-1">
                            <a class="nav-link dropdown-toggle" href="#" id="alertsDropdown" role="button"
                                data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <i class="fas fa-bell fa-fw"></i>
                                <!-- Counter - Alerts -->
                                <span class="badge badge-danger badge-counter">3+</span>
                            </a>
                            <!-- Dropdown - Alerts -->
                            <div class="dropdown-list dropdown-menu dropdown-menu-right shadow animated--grow-in"
                                aria-labelledby="alertsDropdown">
                                <h6 class="dropdown-header">
                                    Alerts Center
                                </h6>
                                <a class="dropdown-item d-flex align-items-center" href="#">
                                    <div class="mr-3">
                                        <div class="icon-circle bg-primary">
                                            <i class="fas fa-file-alt text-white"></i>
                                        </div>
                                    </div>
                                    <div>
                                        <div class="small text-gray-500">December 12, 2019</div>
                                        <span class="font-weight-bold">A new monthly report is ready to download!</span>
                                    </div>
                                </a>
                                <a class="dropdown-item d-flex align-items-center" href="#">
                                    <div class="mr-3">
                                        <div class="icon-circle bg-success">
                                            <i class="fas fa-donate text-white"></i>
                                        </div>
                                    </div>
                                    <div>
                                        <div class="small text-gray-500">December 7, 2019</div>
                                        $290.29 has been deposited into your account!
                                    </div>
                                </a>
                                <a class="dropdown-item d-flex align-items-center" href="#">
                                    <div class="mr-3">
                                        <div class="icon-circle bg-warning">
                                            <i class="fas fa-exclamation-triangle text-white"></i>
                                        </div>
                                    </div>
                                    <div>
                                        <div class="small text-gray-500">December 2, 2019</div>
                                        Spending Alert: We've noticed unusually high spending for your account.
                                    </div>
                                </a>
                                <a class="dropdown-item text-center small text-gray-500" href="#">Show All Alerts</a>
                            </div>
                        </li>

                        <!-- Nav Item - Messages -->
                        <li class="nav-item dropdown no-arrow mx-1">
                            <a class="nav-link dropdown-toggle" href="#" id="messagesDropdown" role="button"
                                data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <i class="fas fa-envelope fa-fw"></i>
                                <!-- Counter - Messages -->
                                <span class="badge badge-danger badge-counter">7</span>
                            </a>
                            <!-- Dropdown - Messages -->
                            <div class="dropdown-list dropdown-menu dropdown-menu-right shadow animated--grow-in"
                                aria-labelledby="messagesDropdown">
                                <h6 class="dropdown-header">
                                    Message Center
                                </h6>
                                <a class="dropdown-item d-flex align-items-center" href="#">
                                    <div class="dropdown-list-image mr-3">
                                        <img class="rounded-circle" src="img/undraw_profile_1.svg" alt="...">
                                        <div class="status-indicator bg-success"></div>
                                    </div>
                                    <div class="font-weight-bold">
                                        <div class="text-truncate">Hi there! I am wondering if you can help me with a
                                            problem I've been having.</div>
                                        <div class="small text-gray-500">Emily Fowler · 58m</div>
                                    </div>
                                </a>
                                <a class="dropdown-item d-flex align-items-center" href="#">
                                    <div class="dropdown-list-image mr-3">
                                        <img class="rounded-circle" src="img/undraw_profile_2.svg" alt="...">
                                        <div class="status-indicator"></div>
                                    </div>
                                    <div>
                                        <div class="text-truncate">I have the photos that you ordered last month, how
                                            would you like them sent to you?</div>
                                        <div class="small text-gray-500">Jae Chun · 1d</div>
                                    </div>
                                </a>
                                <a class="dropdown-item d-flex align-items-center" href="#">
                                    <div class="dropdown-list-image mr-3">
                                        <img class="rounded-circle" src="img/undraw_profile_3.svg" alt="...">
                                        <div class="status-indicator bg-warning"></div>
                                    </div>
                                    <div>
                                        <div class="text-truncate">Last month's report looks great, I am very happy with
                                            the progress so far, keep up the good work!</div>
                                        <div class="small text-gray-500">Morgan Alvarez · 2d</div>
                                    </div>
                                </a>
                                <a class="dropdown-item d-flex align-items-center" href="#">
                                    <div class="dropdown-list-image mr-3">
                                        <img class="rounded-circle" src="https://source.unsplash.com/Mv9hjnEUHR4/60x60"
                                            alt="...">
                                        <div class="status-indicator bg-success"></div>
                                    </div>
                                    <div>
                                        <div class="text-truncate">Am I a good boy? The reason I ask is because someone
                                            told me that people say this to all dogs, even if they aren't good...</div>
                                        <div class="small text-gray-500">Chicken the Dog · 2w</div>
                                    </div>
                                </a>
                                <a class="dropdown-item text-center small text-gray-500" href="#">Read More Messages</a>
                            </div>
                        </li>

                        <div class="topbar-divider d-none d-sm-block"></div>

                        <!-- Nav Item - User Information -->
                        <li class="nav-item dropdown no-arrow">
                            <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button"
                                data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">

                                <?php if (isset($_SESSION['user_name'])) { ?>
                                    <span
                                        class="mr-2 d-none d-lg-inline text-gray-600 small"><?php echo $_SESSION['user_name']; ?></span>
                                <?php } ?>
                                <img class="img-profile rounded-circle" src="assets/img/undraw_profile.svg">

                            </a>
                            <!-- Dropdown - User Information -->
                            <div class="dropdown-menu dropdown-menu-right shadow animated--grow-in"
                                aria-labelledby="userDropdown">
                                <a class="dropdown-item" href="#">
                                    <i class="fas fa-user fa-sm fa-fw mr-2 text-gray-400"></i>
                                    Profile
                                </a>
                                <a class="dropdown-item" href="#">
                                    <i class="fas fa-cogs fa-sm fa-fw mr-2 text-gray-400"></i>
                                    Settings
                                </a>
                                <a class="dropdown-item" href="#">
                                    <i class="fas fa-list fa-sm fa-fw mr-2 text-gray-400"></i>
                                    Activity Log
                                </a>
                                <div class="dropdown-divider"></div>
                                <a class="dropdown-item" href="logout.php" data-toggle="modal"
                                    data-target="#logoutModal">
                                    <i class="fas fa-sign-out-alt fa-sm fa-fw mr-2 text-gray-400"></i>
                                    Logout
                                </a>
                            </div>
                        </li>

                    </ul>

                </nav>
                <!-- End of Topbar -->

                <!-- Begin Page Content -->
                <div class="container-fluid">

                    <!-- Page Heading -->
                    <div class="d-sm-flex align-items-center justify-content-between mb-4">
                        <h1 class="h3 mb-0 text-gray-800">Welcome to Sales</h1>
                        <!-- <a href="#" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm"><i -->
                        <!-- class="fas fa-download fa-sm text-white-50"></i> Generate Report</a> -->
                    </div>

                    <!-- Content Row -->
                    <div class="card shadow mb-4">
                        <div class="card-header py-3">
                            <a href="salesreport.php"
                                class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm"><i
                                    class="fas fa-user fa-sm text-white-50"></i> Sales Report</a>


                            <?php
                            if (isset($_SESSION['msg'])) {
                                echo '<div class="alert alert-primary" role="alert">';
                                echo $_SESSION['msg'];
                                //echo $_SESSION['user'];
                            
                                echo '</div>';
                                unset($_SESSION['msg']); // Clear the message after displaying
                            }
                            if (isset($_SESSION['msgerr'])) {

                                echo '<div class="alert alert-danger" role="alert">';
                                echo $_SESSION['msgerr'];
                                echo '</div>';
                                unset($_SESSION['msgerr']); // Clear the message after displaying
                            
                            }
                            ?>
                        </div>
                        <div class="card-body">
                            <section class="vh-10 gradient-custom">
                                <div class="container py-5 h-100">
                                    <div class="row justify-content-center align-items-center h-100">
                                        <div class="col-12 col-lg-9 col-xl-7">
                                            <div class="card shadow-2-strong card-registration"
                                                style="border-radius: 15px;">
                                                <div class="card-body p-4 p-md-5">
                                                    <h3 class="mb-4 pb-2 pb-md-0 mb-md-5">Sales Voucher</h3>
                                                    <form method="post">
                                                        <div class="row">
                                                            <div class="col-md-6 mb-4">
                                                                <div data-mdb-input-init class="form-outline">
                                                                    <label class="form-label" for="firstName">Select
                                                                        Party Name</label>
                                                                    <!-- <input type="text" id="partyname" name="partyname" class="form-control form-control-lg" autofocus="ON" required /> -->

                                                                    <select class="select form-control-lg"
                                                                        name="partycity" id="partycity">
                                                                        <option value="0">Choose City</option>
                                                                        <?php
                                                                        $sql = "SELECT * FROM `party`";
                                                                        $result = mysqli_query(mysql: $conn, query: $sql);
                                                                        $i = 1;
                                                                        while ($row = $result->fetch_assoc()) {
                                                                            ?>
                                                                            <option value="<?php echo $row['party_id']; ?>">
                                                                                <?php echo $row['partyname']; ?></option>
                                                                        <?php } ?>
                                                                    </select>

                                                                </div>
                                                            </div>
                                                            <div class="col-md-6 mb-4">
                                                                <label class="form-label select-label">Choose
                                                                    City</label>
                                                                <select class="select form-control-lg" name="partycity"
                                                                    id="partycity">
                                                                    <option value="0">Choose City</option>
                                                                    <option value="Kanodar">Kanodar</option>
                                                                    <option value="Chhapi">Chhapi</option>
                                                                    <option value="Palanpur">Palanpur</option>
                                                                    <option value="Sidhhpur">Sidhhpur</option>
                                                                </select>
                                                            </div>
                                                        </div>
                                                        <div class="row">
                                                            <div class="col-md-6 mb-4 d-flex align-items-center">
                                                                <div data-mdb-input-init
                                                                    class="form-outline datepicker w-100">
                                                                    <label for="birthdayDate" class="form-label">Party
                                                                        Group</label>
                                                                    <select class="select form-control-lg"
                                                                        name="partygroup" id="partygroup">
                                                                        <option value="0">Choose Group</option>
                                                                        <?php
                                                                        $sqlpro = "SELECT * FROM `product`";
                                                                        $resultpro = mysqli_query(mysql: $conn, query: $sqlpro);
                                                                        $i = 1;
                                                                        while ($rowpro = $resultpro->fetch_assoc()) {
                                                                            ?>
                                                                        <option value="<?php echo $rowpro['productid']; ?>"><?php echo $rowpro['productname']; ?></option>
                                                                        <?php } ?>

                                                                    </select>
                                                                </div>
                                                            </div>
                                                            <div class="col-md-6 mb-4">

                                                            </div>
                                                        </div>

                                                        <div class="row">
                                                            <div class="col-md-6 mb-4 d-flex align-items-center">
                                                                <div data-mdb-input-init
                                                                    class="form-outline datepicker w-100">
                                                                    <label for="birthdayDate" class="form-label">Mobile
                                                                        No:</label>
                                                                    <input type="text"
                                                                        class="form-control form-control-lg"
                                                                        id="partycontact" name="partycontact" />
                                                                </div>
                                                            </div>

                                                        </div>

                                                        <div class="mt-4 pt-2">
                                                            <input data-mdb-ripple-init class="btn btn-primary btn-lg"
                                                                type="submit" value="Submit" name="submit" />
                                                        </div>
                                                    </form>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </section>
                        </div>
                    </div>
                </div>
            </div>
            <!-- End of Main Content -->

            <?php include 'footer.php';
            if (isset($_REQUEST['submit'])) {
                $sql = "INSERT INTO `party`(`partyname`, `partycity`, `partygroup`, `partycontact`) VALUES ('$_REQUEST[partyname]','$_REQUEST[partycity]','$_REQUEST[partygroup]','$_REQUEST[partycontact]')";
                $result = mysqli_query(mysql: $conn, query: $sql);
                if ($result) {
                    $_SESSION['msg'] = "Party has been Added successfully";
                    header('Location:showparty.php');
                }
            }
            ?>
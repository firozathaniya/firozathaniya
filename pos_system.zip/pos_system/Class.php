<?php
session_start();
 include 'Dbconnection.php'; 

     if($_SERVER['REQUEST_METHOD']=="POST") 
            {
                 $sql="INSERT INTO `user`(`firstname`, `lastname`, `email`, `password`, `status`) VALUES ('$_REQUEST[firstname]','$_REQUEST[lastname]','$_REQUEST[email]','$_REQUEST[password]','deactive')";        
              $result = mysqli_query(mysql: $conn, query: $sql);
            if($result=="true")
            {
               // echo "DATA INSERT SUCCESS ";
                $_SESSION['success_message'] = "Data submitted successfully!";
               header('Location: index.php');
            }
            else
                {
                     $_SESSION['error_message'] = "data insert failed";
                     header('Location: index.php');
                    
                   
                }
            }
       
       

?>
<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "pos_system";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);

// Check connection
//if (!$conn) {
   // die("Connection failed: " . mysqli_connect_error());
//}
//echo "Connected successfully using MySQLi (Procedural)";

// Perform database operations here

// Close connection
//mysqli_close($conn);
?>